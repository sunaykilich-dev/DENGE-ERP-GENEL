"""Test altyapısı.

Üç şey kaynak projeden bilinçli olarak farklı (plan §7):

1. **Gömülü Postgres YOK.** `pgserver` PostgreSQL 16.2 getiriyor ve uzantı
   listesinde `btree_gist` yok; ERP'nin çekirdek kısıtı
   `EXCLUDE USING gist (device_id WITH =, tstzrange(...) WITH &&)`
   o uzantı olmadan yazılamaz. Testler Compose'daki PostgreSQL 17'ye bağlanır.

2. **Şema `alembic upgrade head` ile kurulur**, `Base.metadata.create_all` ile
   değil. Böylece her koşu migration zincirini de doğrular — 60 tabloya
   çıkacak bir şemada kısmi indeks/EXCLUDE kısıtlarını conftest'e elle
   kopyalamak sürdürülemezdi.

3. **AYRI VERİTABANI.** Testler asla geliştirme veritabanına dokunmaz:
   `dengeerp` yerine `dengeerp_test`. Her test öncesi tablolar boşaltılır.
"""

import os
import subprocess
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit

import pytest
import pytest_asyncio
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

import app.models  # noqa: F401 — modellerin tamamı metadata'ya kaydolsun
from app.config import get_config

BACKEND_DIR = Path(__file__).resolve().parents[1]

# Referans tabloları dahil her şey temizlenir; alembic_version kalır.
_TRUNCATE = """
TRUNCATE TABLE audit_logs, attachments, sim_device_history, sim_plan_history,
               sim_cards, device_status_history, devices, vehicles,
               product_bundle_items, products, installation_partners,
               contacts, addresses, accounts, sessions, login_attempts,
               settings, card_comments, card_members, card_labels, cards,
               board_labels, board_columns, boards,
               user_permissions, users, role_permissions, roles, permissions
RESTART IDENTITY CASCADE
"""


def _test_database_url() -> str:
    """TEST_DATABASE_URL verilmişse onu, yoksa geliştirme URL'sinin `_test`
    eklenmiş halini kullanır. Aynı veritabanına ASLA düşmez."""
    if env := os.getenv("TEST_DATABASE_URL"):
        return env
    parts = urlsplit(get_config().database_url)
    dev_db = parts.path.lstrip("/")
    return urlunsplit(parts._replace(path=f"/{dev_db}_test"))


@pytest.fixture(scope="session")
def test_db_url() -> str:
    url = _test_database_url()
    assert url != get_config().database_url, "Test veritabanı geliştirme veritabanıyla aynı olamaz"
    return url


@pytest.fixture(scope="session", autouse=True)
def _schema(test_db_url: str) -> None:
    """Test veritabanını (yoksa) oluşturur ve migration'ları uygular."""
    parts = urlsplit(test_db_url)
    db_name = parts.path.lstrip("/")
    admin_url = urlunsplit(parts._replace(path="/postgres"))

    import psycopg

    sync_admin = admin_url.replace("postgresql+psycopg://", "postgresql://", 1)
    try:
        with psycopg.connect(sync_admin, autocommit=True) as conn:
            exists = conn.execute(
                "SELECT 1 FROM pg_database WHERE datname = %s", (db_name,)
            ).fetchone()
            if not exists:
                conn.execute(f'CREATE DATABASE "{db_name}"')
    except psycopg.OperationalError as exc:  # pragma: no cover - ortam hatası
        pytest.skip(f"PostgreSQL'e bağlanılamadı ({exc}). 'make db' ile ayağa kaldırın.")

    subprocess.run(
        ["uv", "run", "alembic", "upgrade", "head"],
        cwd=BACKEND_DIR,
        env={**os.environ, "DATABASE_URL": test_db_url},
        check=True,
        capture_output=True,
    )


@pytest.fixture(scope="session", autouse=True)
def _dosya_dizini(tmp_path_factory) -> None:
    """Ek yükleme testleri geliştirme dosya dizinine YAZMAMALI.

    `FILES_DIR` oturum başına geçici bir dizine çevrilir; aksi halde her test
    koşusu `var/files` altına çöp bırakırdı ve "aynı içerik bir kez saklanır"
    testi önceki koşudan kalan dosyayla yanıltıcı biçimde geçerdi.
    """
    from app.config import get_config

    get_config.cache_clear()
    os.environ["FILES_DIR"] = str(tmp_path_factory.mktemp("files"))
    # Testler MFA'sız kullanıcılarla iş mantığını sınıyor; zorunluluk açık
    # kalsaydı hepsi kurulum kapısına takılırdı. Kapının KENDİSİ ayrıca test
    # ediliyor (tests/integration/test_mfa_zorunlulugu.py), orada açılıyor.
    os.environ["MFA_ZORUNLU"] = "false"
    get_config.cache_clear()


@pytest_asyncio.fixture
async def engine(test_db_url: str):
    engine = create_async_engine(test_db_url)
    async with engine.begin() as conn:
        await conn.execute(text(_TRUNCATE))
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def session_factory(engine):
    return async_sessionmaker(engine, expire_on_commit=False)


@pytest_asyncio.fixture
async def db(session_factory):
    async with session_factory() as session:
        yield session


@pytest_asyncio.fixture
async def seeded(db):
    """Roller ve izinler yüklenmiş veritabanı."""
    from app.seeds.dev import sync_permissions, sync_roles

    await sync_permissions(db)
    await sync_roles(db)
    await db.commit()
    return db


@pytest_asyncio.fixture
async def client(session_factory, seeded):
    """Oturum çerezini taşıyan HTTP istemcisi; testler gerçek uçları çağırır."""
    import httpx

    from app.api.deps import get_clock
    from app.clock import FakeClock
    from app.db import get_session
    from app.main import app

    async def _session_override():
        async with session_factory() as s:
            yield s

    fake = FakeClock()
    app.dependency_overrides[get_session] = _session_override
    app.dependency_overrides[get_clock] = lambda: fake

    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        headers={"X-Requested-With": "fetch"},  # CSRF başlığı
    ) as c:
        c.clock = fake  # testler zamanı ilerletebilsin
        yield c
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def kullanici_ac(db):
    """Verilen rolde kullanıcı açan yardımcı."""
    from sqlalchemy import select

    from app.models import Role, User
    from app.services import auth as auth_service

    async def _make(username: str, role_code: str, password: str = "parola1234") -> User:
        role = await db.scalar(select(Role).where(Role.code == role_code))
        assert role is not None, f"rol yok: {role_code}"
        user = User(
            full_name=username.title(),
            username=username,
            password_hash=auth_service.hash_password(password),
            role_id=role.id,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    return _make


@pytest_asyncio.fixture
async def urun_ac(db):
    """Verilen kimlik tipinde ürün açar."""
    from app.models import Product

    async def _make(code: str, identity_kind: str = "IMEI", **kw) -> Product:
        urun = Product(code=code, name=f"{code} Ürün", identity_kind=identity_kind, **kw)
        db.add(urun)
        await db.commit()
        await db.refresh(urun)
        return urun

    return _make


@pytest_asyncio.fixture
async def cihaz_ac(db, urun_ac):
    """Cihaz açar; ürün verilmezse IMEI tipinde bir ürün üretir."""
    from app.models import Device

    varsayilan: dict = {}

    async def _make(*, imei=None, serial_no=None, urun=None, **kw) -> Device:
        if urun is None:
            if "imei" not in varsayilan:
                varsayilan["imei"] = await urun_ac("TEST-IMEI", "IMEI")
            urun = varsayilan["imei"]
        cihaz = Device(
            imei=imei,
            serial_no=serial_no,
            product_id=urun.id,
            identity_kind=urun.identity_kind,
            **kw,
        )
        db.add(cihaz)
        await db.commit()
        await db.refresh(cihaz)
        return cihaz

    return _make


@pytest_asyncio.fixture
async def hat_ac(db):
    from app.models import SimCard

    async def _make(iccid: str, **kw) -> SimCard:
        hat = SimCard(iccid=iccid, **kw)
        db.add(hat)
        await db.commit()
        await db.refresh(hat)
        return hat

    return _make
